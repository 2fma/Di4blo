"""
accessory module used to design and color the output text for pretty terminal
output.
"""
from rich.console import Console

# Placeholder function to maintain compatibility with the 'from accessories import start as start_animation' import
def start(*args, **kwargs):
    """
    Placeholder for the old start function.
    The main banner is now printed directly in diablorecon.py's main function.
    """
    pass


class Notify:
    """
    This class handles the beautiful terminal output using the rich library
    """
    @staticmethod
    def found(site: str, url: str) -> str:
        # Changed green to white, yellow to bright_red
        return f"[bright_red][[white]@[bright_red]] [white]{site}[/white] found! [red]{url}[/red]"

    @staticmethod
    def not_found(site: str, reason: str) -> str:
        # Changed yellow to white
        return f"[bright_red][[red]![bright_red]] [red]{site}[/red] not found! [white]({reason})[/white]"

    @staticmethod
    def error(message: str) -> str:
        # Changed yellow to white
        return f"[bright_red][[red]![bright_red]] [red]ERROR:[/red] [white]{message}[/white]"

    @staticmethod
    def warning(message: str) -> str:
        # Changed yellow to bright_red
        return f"[bright_red][[red]![bright_red]] [bright_red]{message}[/bright_red]"

    @staticmethod
    def stored_result(filename: str) -> str:
        # Changed cyan to red, yellow to white
        return f"[bright_red][[white]@[bright_red]] [red]Results stored in: [white]{filename}[/white]"
    
    @staticmethod
    def pdf_stored_result(filename: str) -> str:
        # Changed cyan to red, yellow to white
        return f"[bright_red][[white]@[bright_red]] [red]PDF report generated: [white]{filename}[/white]"

    @staticmethod
    def update(local_version: str, remote_version: str) -> str:
        # Changed green to white, cyan to red, yellow to bright_red
        return (
            f"[bright_red][[white]@[bright_red]] [red]New update available: [bright_red]{local_version}[/bright_red] -> [white]{remote_version}[/white]"
            "\n[bright_red][[red]![bright_red]] [red]Run [white]python3 diablorecon.py -U[/white] to update."
        )

    @staticmethod
    def update_error(message: str) -> str:
        # Changed yellow to white
        return f"[bright_red][[red]![bright_red]] [red]Update Error: [white]{message}[/white]"

    @staticmethod
    def version(local_version: str) -> str:
        # Changed green to white, cyan to red, yellow to bright_red
        return f"[bright_red][[white]@[bright_red]] [red]Diablo Recon Version: [white]{local_version}[/white]"

    @staticmethod
    def usage_notes() -> str:
        # Changed yellow to bright_red, cyan to white
        return (
            "\n[bright_red][[red]![bright_red]] [bright_red]Usage Notes:[bright_red]"
            "\n[white] - The tool checks for 200/404 HTTP codes or specific Soft-404 indicators."
            "\n - Accuracy is improved with the expanded site list."
            "\n - Use [-p | --pdf] to generate a PDF report of found results."
            "\n - Results are saved in the 'data' folder (TXT and PDF)."
        )
    @staticmethod
    def start_search(username: str) -> str:
        # Changed cyan to red, yellow to bright_red
        return f"[bright_red][[white]![bright_red]] [red]Starting search for: [bright_red]{username}[/bright_red]\n"

    @staticmethod
    def end_search(count: int) -> str:
        # Changed green to white, yellow to bright_red
        return f"\n[bright_red][[white]@[bright_red]] [white]Search finished! [bright_red]{count}[/bright_red] profiles found."

    @staticmethod
    def no_update(local_version: str) -> str:
        # Changed green to white, yellow to bright_red
        return f"[bright_red][[white]@[bright_red]] [bright_red]You are running the latest version: [white]{local_version}[/white]"

    @staticmethod
    def updating() -> str:
        # Changed cyan to red
        return "[bright_red][[red]![bright_red]] [red]Attempting to update Diablo Recon..."

    @staticmethod
    def update_success() -> str:
        # Changed green to white
        return "[bright_red][[white]@[bright_red]] [white]Diablo Recon successfully updated![/white]"