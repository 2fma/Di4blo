#! /usr/bin/env python3
"""
Diablo Recon: Unmasking Digital Shadows with Precision.
The modernized core logic for DiabloMode.
"""
import os
import re
import json 
import datetime
import subprocess
import threading
import random
import requests
from argparse import ArgumentParser, SUPPRESS
from rich.console import Console
from bs4 import BeautifulSoup
from pathlib import Path

# New import for PDF generation
from fpdf import FPDF

# Corrected Import based on our accessories.py:
from accessories import Notify, start as start_animation 
# We import the utility lists. The main site dictionary is handled in load_sites_from_json.
from sites import soft404_indicators, user_agents 


__version__ = "1.0.0-twat" 

# ----------------------------------------------------------------------
# Site Loading Logic (Handles wmn-data.json or sites.py fallback)
# ----------------------------------------------------------------------

# FIX: Replaced with the more robust load_sites_from_json function
def load_sites_from_json(file_path: str = "wmn-data.json") -> dict:
    """Loads the massive site dictionary from a JSON file, falling back to sites.py if missing or empty."""
    console = Console()

    # 1. Check if wmn-data.json file exists. If not, fallback immediately.
    if not Path(file_path).exists():
        # Ensure 'sites' is imported only when needed to avoid circular dependencies if sites.py is large
        try:
            from sites import sites as small_site_list
            console.print(Notify.warning(f"'{file_path}' not found. Falling back to the smaller site list in sites.py."))
            # Adapt the smaller sites.py structure to match the expected format
            return {
                name: {'url': url, 'error_text': []} # Using 'error_text' for consistency
                for name, url in small_site_list.items()
            }
        except ImportError:
            console.print(Notify.error("Could not import 'sites' dictionary from 'sites.py'. No site data available."))
            return {}
        except Exception as e:
            console.print(Notify.error(f"Unexpected error during 'sites.py' fallback load: {e.__class__.__name__}"))
            return {}


    sites_data = {}
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        if isinstance(data, dict):
            # Robust Filter: Entry must be a dictionary AND must contain a 'uri_check' or 'url' key
            # Also, exclude common metadata keys like "about", "contact", etc.
            metadata_keys = {"license", "about", "contact", "info", "description", "version", "authors"}
            
            sites_data = {
                site_name: site_info
                for site_name, site_info in data.items()
                if isinstance(site_info, dict) and 
                   ( 'uri_check' in site_info or 'url' in site_info ) and
                   site_name.lower() not in metadata_keys
            }

        if sites_data:
            return sites_data
        else:
            # THIS HANDLES THE USER'S REPORTED WARNING: JSON was present but empty or only contained metadata
            console.print(Notify.warning(f"'{file_path}' loaded but contained no valid site entries. Checking fallback."))
            
            # Fallback to sites.py if the JSON file was present but invalid/empty
            try:
                from sites import sites as small_site_list
                console.print(Notify.warning("Falling back to the smaller site list in sites.py."))
                return {
                    name: {'url': url, 'error_text': []} # Using 'error_text' for consistency
                    for name, url in small_site_list.items()
                }
            except ImportError:
                console.print(Notify.error("Could not import 'sites' dictionary from 'sites.py'. No fallback site data available."))
                return {}
            except Exception as e:
                console.print(Notify.error(f"Unexpected error during 'sites.py' fallback load: {e.__class__.__name__}"))
                return {}

    except FileNotFoundError:
        # Should be caught by the initial check, but kept for robustness
        console.print(Notify.error(f"Site data file not found: {file_path}"))
        return {}
    except json.JSONDecodeError:
        console.print(Notify.error(f"Invalid JSON in {file_path}. Check the file content."))
        return {}
    except Exception as e:
        console.print(Notify.error(f"An unexpected error occurred while loading site data from '{file_path}': {e.__class__.__name__}"))
        return {}


# ----------------------------------------------------------------------
# DiabloMode Core Class
# ----------------------------------------------------------------------

class DiabloMode: 
    def __init__(self, username: str, quiet_mode=False, export_pdf=False, verbose_errors=False):
        self.console = Console()
        self.notify = Notify
        self.positive_count = 0
        self.username = username
        
        self.sites = load_sites_from_json() 
        
        self.data_dir = Path("data")
        self.result_file = self.data_dir / f"{self.username}.txt"
        self.pdf_file = self.data_dir / f"{self.username}.pdf"
        
        self.quiet_mode = quiet_mode  
        self.export_pdf = export_pdf
        self.verbose_errors = verbose_errors
        self.found_results = [] 


    def check_site(self, site_name, site_info):
        """Perform the actual check for a single site."""
        
        # Determine the URL and placeholder based on source (small list or large JSON)
        if 'url' in site_info: # Old small list format (sites.py)
            url_format = site_info['url']
            url = url_format.format(self.username)
            error_strings = site_info.get('error_text', soft404_indicators)
            check_url = url
        elif 'uri_check' in site_info: # New large JSON format (wmn-data.json)
            url_format = site_info['uri_check']
            # Handle both {account} and {} placeholders
            url = url_format.replace('{account}', self.username).replace('{}', self.username)
            
            # The JSON format uses 'e_string' for the error text (if available)
            error_strings = site_info.get('e_string', soft404_indicators)
            check_url = url
        else:
            return # Skip if no valid URL key

        try:
            headers = {'User-Agent': random.choice(user_agents)}
            response = requests.get(
                check_url, 
                headers=headers, 
                timeout=10, 
                allow_redirects=True
            )

            # --- Primary Check: HTTP Status Code ---
            if response.status_code == 200:
                # --- Secondary Check: Soft 404 Indicators ---
                is_soft_404 = any(
                    err_string.lower() in response.text.lower() 
                    for err_string in error_strings
                )
                
                if not is_soft_404:
                    # FOUND (200 OK without soft 404)
                    self.console.print(self.notify.found(site_name, response.url))
                    self.found_results.append(f"[+] {site_name}: {response.url}")
                    self.positive_count += 1
                else:
                    # NOT FOUND (Soft 404 detected)
                    if not self.quiet_mode:
                        self.console.print(self.notify.not_found(site_name, "Soft-404 text detected"))
                        
            elif response.status_code == 404 or response.status_code == 410:
                # NOT FOUND (404/410)
                if not self.quiet_mode:
                    self.console.print(self.notify.not_found(site_name, f"HTTP {response.status_code}"))
            else:
                # Other status codes (403, 500, etc.)
                if not self.quiet_mode:
                    self.console.print(self.notify.not_found(site_name, f"HTTP {response.status_code}"))

        except requests.exceptions.Timeout:
            if self.verbose_errors:
                self.console.print(self.notify.error(f"{site_name}: Connection timed out."))
        except requests.exceptions.ConnectionError:
            if self.verbose_errors:
                self.console.print(self.notify.error(f"{site_name}: Connection error (DNS, refused, etc.)."))
        except requests.exceptions.RequestException as e:
            if self.verbose_errors:
                self.console.print(self.notify.error(f"{site_name}: An unexpected request error occurred. ({e.__class__.__name__})"))
        except Exception as e:
            if self.verbose_errors:
                self.console.print(self.notify.error(f"{site_name}: An unexpected error occurred. ({e.__class__.__name__})"))


    def start(self):
        """Start the search process and handle post-search tasks."""
        if not self.sites:
            # Error message already printed by load_sites_from_json
            return
            
        self.console.print(self.notify.start_search(self.username))
        
        # Use threading to speed up the process
        threads = []
        for site_name, site_info in self.sites.items():
            t = threading.Thread(target=self.check_site, args=(site_name, site_info))
            threads.append(t)
            t.start()
            
        # Wait for all threads to complete
        for t in threads:
            t.join()

        # Post-search tasks
        self.console.print(self.notify.end_search(self.positive_count))
        
        if self.found_results:
            self.save_results_to_txt()
            if self.export_pdf:
                self.generate_pdf_report()
        else:
            self.console.print(self.notify.warning("No profiles were found."))
            

    def save_results_to_txt(self):
        """Save found profiles to a text file."""
        self.data_dir.mkdir(exist_ok=True)
        with open(self.result_file, 'w') as f:
            f.write(f"Diablo Recon Results for: {self.username}\n")
            f.write("-" * (len(self.username) + 26) + "\n\n")
            for result in self.found_results:
                f.write(result + '\n')
        self.console.print(self.notify.stored_result(str(self.result_file)))

    def generate_pdf_report(self):
        """Generate a PDF report of found profiles."""
        self.data_dir.mkdir(exist_ok=True)
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", "B", 16)
        pdf.cell(0, 10, f"Diablo Recon Report: {self.username}", 0, 1, "C")
        
        pdf.set_font("Arial", "", 12)
        pdf.cell(0, 10, f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 0, 1, "C")
        pdf.ln(10)

        pdf.set_font("Arial", "B", 12)
        pdf.cell(0, 10, "Found Profiles:", 0, 1)
        pdf.set_font("Arial", "", 10)
        
        for result in self.found_results:
            site_name, url = result.split(': ', 1)
            pdf.cell(40, 7, site_name.replace('[+]', '').strip(), 1)
            pdf.cell(0, 7, url.strip(), 1, 1, 'L', link=url.strip())
            
        pdf.output(self.pdf_file)
        self.console.print(self.notify.pdf_stored_result(str(self.pdf_file)))


# ----------------------------------------------------------------------
# Update and Main Functions
# ----------------------------------------------------------------------

def update_diablomode(console: Console, notify: Notify) -> None:
    """Update Diablo Recon by pulling the latest changes via Git"""
    try:
        console.print(notify.updating())
        subprocess.run(
            ["git", "pull", "origin", "master"], check=True, capture_output=True
        )
        console.print(notify.update_success())
    except subprocess.CalledProcessError as e:
        console.print(notify.update_error(f"Git command failed: {e.stderr.decode()}"))
    except FileNotFoundError:
        console.print(
            notify.update_error(
                "Git command not found. Please ensure Git is installed and in your PATH."
            )
        )
    except Exception as e:
        console.print(notify.update_error(f"An unexpected error occurred: {e}"))


def main():
    """
    Main function to parse arguments and run Diablo Recon
    """
    # Create data folder if it doesn't exist
    Path("data").mkdir(exist_ok=True)

    console = Console()
    
    # NEW, SHADED BLOCK ASCII ART BANNER
    console.print(
        f"[bright_red]"""
        r"""                                                                            """ "\n"
        r"""░███████   ░██████   ░███    ░████████   ░██           ░██████    """ "\n"
        r"""░██   ░██    ░██    ░██░██   ░██    ░██  ░██          ░██   ░██   """ "\n"
        r"""░██    ░██   ░██   ░██  ░██  ░██    ░██  ░██          ░██     ░██ """ "\n"
        r"""░██    ░██   ░██  ░█████████ ░████████   ░██          ░██     ░██ """ "\n"
        r"""░██    ░██   ░██  ░██    ░██ ░██    ░██  ░██          ░██     ░██ """ "\n"
        r"""░██   ░██    ░██  ░██    ░██ ░██    ░██  ░██           ░██   ░██   """ "\n"
        r"""░███████   ░██████░██    ░██ ░█████████  ░██████████   ░██████    """ "\n"
        r"""                                                                            """ "\n"
        r"""                                                                            """ "\n"
        r"""                                                                            """ "\n"
        f"[/bright_red][red]       𝙳𝙸𝙰𝙱𝙻𝙾 RECON 𝙱𝚈 𝙰7𝙵  v[white]{__version__}[/white]              [/red]"
    )

    parser = ArgumentParser(
        prog="diablorecon",
        description=f"PERSONAL DFIR TOOL (v{__version__}).",
    )
    
    # --- Input Arguments (Mutually Exclusive) ---
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "-u",
        "--username",
        dest="username",
        help="A single username to search for.",
        action="store",
    )
    group.add_argument(
        "-f",
        "--file",
        dest="username_file",
        help="A file containing a list of usernames to search for (one per line).",
        action="store",
    )
    
    # --- Control/Output Arguments ---
    parser.add_argument(
        "-p",
        "--pdf",
        dest="export_pdf",
        help="Export found results to a PDF report.",
        action="store_true",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        dest="found",
        help="Only output found profiles (Quiet Mode).",
        action="store_true",
    )
    parser.add_argument(
        "-d",
        "--diablo-verbose",
        dest="diablo_verbose",
        help="Enable maximum verbosity: prints detailed connection error messages.",
        action="store_true",
    )

    # --- Info Arguments ---
    parser.add_argument(
        "-v",
        "--version",
        dest="show_version",
        help="Print Diablo Recon Version.",
        action="store_true",
    )
    parser.add_argument(
        "-U", 
        "--update", 
        dest="do_update", 
        help="Update Diablo Recon using Git.", 
        action="store_true"
    )

    # Argument for positional username
    parser.add_argument(
        "positional_username",
        nargs='?', # 0 or 1 argument
        default=None,
        help=SUPPRESS, 
    )

    args = parser.parse_args()

    # --- Initialization Logic ---
    
    # Handle version and update flags first
    if args.show_version:
        console.print(Notify.version(__version__)) 
        return
    
    if args.do_update:
        update_diablomode(console, Notify)
        return
    
    # Prioritize -u/-f, then positional argument
    username_arg = args.username or args.positional_username
    
    # Determine the list of usernames to process
    usernames_to_process = []
    
    if username_arg:
        usernames_to_process.append(username_arg)
    elif args.username_file:
        try:
            with open(args.username_file, 'r') as f:
                # Clean and filter empty lines
                usernames_to_process.extend([line.strip() for line in f if line.strip()])
        except FileNotFoundError:
            console.print(Notify.error(f"Username file not found: {args.username_file}"))
            return
    else:
        # No arguments provided, show help message
        parser.print_help()
        console.print(Notify.usage_notes())
        return

    # Process all usernames in the list
    for username in usernames_to_process:
        diablo = DiabloMode( 
            username=username, 
            quiet_mode=args.found, 
            export_pdf=args.export_pdf,
            verbose_errors=args.diablo_verbose
        )
        
        # Check if sites were loaded successfully before starting the search
        if diablo.sites:
            diablo.start()
        else:
            # If sites are empty, the error message was already printed by load_sites_from_json
            return 
    
if __name__ == "__main__":
    main()