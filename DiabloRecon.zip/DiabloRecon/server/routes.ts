import type { Express } from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import { storage } from "./storage";
import { searchManager } from "./searchManager";
import { insertSearchSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Search Routes
  
  // Start a new search
  app.post("/api/search", async (req, res) => {
    try {
      const validatedData = insertSearchSchema.parse(req.body);
      console.log(`Starting search for username: ${validatedData.username}`);
      
      const { searchId, search } = await searchManager.startSearch(validatedData.username);
      
      res.json({
        success: true,
        searchId,
        search
      });
    } catch (error) {
      console.error("Error starting search:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          error: "Invalid request data",
          details: error.errors
        });
      } else {
        res.status(500).json({
          success: false,
          error: "Failed to start search"
        });
      }
    }
  });

  // Get search status and results
  app.get("/api/search/:id", async (req, res) => {
    try {
      const searchId = req.params.id;
      
      // Get from storage first
      const search = await storage.getSearch(searchId);
      if (!search) {
        return res.status(404).json({
          success: false,
          error: "Search not found"
        });
      }

      // Get live progress if search is active
      const liveProgress = searchManager.getSearchProgress(searchId);
      
      res.json({
        success: true,
        search,
        liveProgress
      });
    } catch (error) {
      console.error("Error getting search:", error);
      res.status(500).json({
        success: false,
        error: "Failed to get search"
      });
    }
  });

  // Stop a search
  app.post("/api/search/:id/stop", async (req, res) => {
    try {
      const searchId = req.params.id;
      const stopped = searchManager.stopSearch(searchId);
      
      if (stopped) {
        await storage.updateSearch(searchId, {
          status: "cancelled",
          completedAt: new Date()
        });
      }
      
      res.json({
        success: true,
        stopped
      });
    } catch (error) {
      console.error("Error stopping search:", error);
      res.status(500).json({
        success: false,
        error: "Failed to stop search"
      });
    }
  });

  // Get all searches for a username
  app.get("/api/searches/:username", async (req, res) => {
    try {
      const username = req.params.username;
      const searches = await storage.getSearchesByUsername(username);
      
      res.json({
        success: true,
        searches
      });
    } catch (error) {
      console.error("Error getting searches:", error);
      res.status(500).json({
        success: false,
        error: "Failed to get searches"
      });
    }
  });

  // Get site categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = searchManager.getSiteCategories();
      
      res.json({
        success: true,
        categories
      });
    } catch (error) {
      console.error("Error getting categories:", error);
      res.status(500).json({
        success: false,
        error: "Failed to get categories"
      });
    }
  });

  // Export search results as TXT
  app.get("/api/search/:id/export/txt", async (req, res) => {
    try {
      const searchId = req.params.id;
      const search = await storage.getSearch(searchId);
      
      if (!search) {
        return res.status(404).json({
          success: false,
          error: "Search not found"
        });
      }

      const results = search.results as any[];
      const foundResults = results.filter(r => r.status === "found");
      
      const txtContent = [
        `Diablo Recon Results for: ${search.username}`,
        "-".repeat(search.username.length + 26),
        "",
        ...foundResults.map(result => `[+] ${result.site}: ${result.url}`)
      ].join("\n");

      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", `attachment; filename="${search.username}_results.txt"`);
      res.send(txtContent);
    } catch (error) {
      console.error("Error exporting TXT:", error);
      res.status(500).json({
        success: false,
        error: "Failed to export results"
      });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup for real-time updates
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  io.on("connection", (socket) => {
    console.log("Client connected:", socket.id);

    socket.on("join-search", (searchId: string) => {
      socket.join(searchId);
      console.log(`Client ${socket.id} joined search room: ${searchId}`);
    });

    socket.on("leave-search", (searchId: string) => {
      socket.leave(searchId);
      console.log(`Client ${socket.id} left search room: ${searchId}`);
    });

    socket.on("disconnect", () => {
      console.log("Client disconnected:", socket.id);
    });
  });

  return httpServer;
}
