import { SearchResult, SearchProgress } from "@shared/schema";
import { sites, globalErrorIndicators, userAgents, SiteConfig } from "./sites";
import { EventEmitter } from "events";

export class SearchService extends EventEmitter {
  private searchId: string;
  private username: string;
  private progress: SearchProgress;
  private results: SearchResult[] = [];
  private isActive = false;
  private startTime = 0;

  constructor(searchId: string, username: string) {
    super();
    this.searchId = searchId;
    this.username = username;
    this.progress = {
      current: 0,
      total: Object.keys(sites).length,
      foundCount: 0,
    };
  }

  async startSearch(): Promise<void> {
    if (this.isActive) {
      throw new Error("Search already in progress");
    }

    this.isActive = true;
    this.startTime = Date.now();
    this.results = [];
    this.progress = {
      current: 0,
      total: Object.keys(sites).length,
      foundCount: 0,
    };

    this.emit("progress", this.progress);
    this.emit("status", "running");

    console.log(`Starting search for username: ${this.username} across ${this.progress.total} sites`);

    const siteEntries = Object.entries(sites);
    const batchSize = 10; // Process sites in batches to avoid overwhelming servers
    
    for (let i = 0; i < siteEntries.length; i += batchSize) {
      if (!this.isActive) break; // Allow for search cancellation
      
      const batch = siteEntries.slice(i, i + batchSize);
      const promises = batch.map(([siteName, siteConfig]) => 
        this.checkSite(siteName, siteConfig)
      );
      
      await Promise.allSettled(promises);
      
      // Small delay between batches to be respectful to servers
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    this.isActive = false;
    this.emit("status", "completed");
    console.log(`Search completed for ${this.username}. Found ${this.progress.foundCount} profiles.`);
  }

  private async checkSite(siteName: string, siteConfig: SiteConfig): Promise<void> {
    const url = siteConfig.url.replace("{}", this.username);
    const errorIndicators = [...(siteConfig.errorIndicators || []), ...globalErrorIndicators];
    
    this.progress.currentSite = siteName;
    this.emit("progress", { ...this.progress });

    // Add checking status result
    const checkingResult: SearchResult = {
      site: siteName,
      url: "",
      status: "checking",
      category: siteConfig.category,
    };
    this.results.push(checkingResult);
    this.emit("result", checkingResult);

    try {
      const startTime = Date.now();
      const userAgent = userAgents[Math.floor(Math.random() * userAgents.length)];
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

      const response = await fetch(url, {
        headers: {
          'User-Agent': userAgent,
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
        signal: controller.signal,
        redirect: 'follow'
      });
      
      clearTimeout(timeoutId);
      const responseTime = Date.now() - startTime;
      const responseText = await response.text();

      let status: SearchResult["status"] = "not_found";
      let resultUrl = "";

      if (response.status === 200) {
        // Check for soft 404 indicators
        const isSoft404 = errorIndicators.some(indicator => 
          responseText.toLowerCase().includes(indicator.toLowerCase())
        );

        if (!isSoft404) {
          status = "found";
          resultUrl = response.url; // Use final URL after redirects
          this.progress.foundCount++;
          console.log(`✓ Found: ${siteName} - ${resultUrl}`);
        } else {
          console.log(`✗ Not found: ${siteName} - Soft 404 detected`);
        }
      } else if (response.status === 404 || response.status === 410) {
        console.log(`✗ Not found: ${siteName} - HTTP ${response.status}`);
      } else {
        status = "error";
        console.log(`⚠ Error: ${siteName} - HTTP ${response.status}`);
      }

      // Update the result
      const result: SearchResult = {
        site: siteName,
        url: resultUrl,
        status,
        category: siteConfig.category,
        responseTime: status === "found" ? responseTime : undefined,
      };

      // Replace the checking result
      const index = this.results.findIndex(r => r.site === siteName);
      if (index !== -1) {
        this.results[index] = result;
      } else {
        this.results.push(result);
      }

      this.emit("result", result);

    } catch (error) {
      console.log(`⚠ Error checking ${siteName}:`, error);
      
      const errorResult: SearchResult = {
        site: siteName,
        url: "",
        status: "error",
        category: siteConfig.category,
      };

      // Replace the checking result
      const index = this.results.findIndex(r => r.site === siteName);
      if (index !== -1) {
        this.results[index] = errorResult;
      } else {
        this.results.push(errorResult);
      }

      this.emit("result", errorResult);
    }

    this.progress.current++;
    this.emit("progress", { ...this.progress });
  }

  stopSearch(): void {
    this.isActive = false;
    this.emit("status", "cancelled");
  }

  getProgress(): SearchProgress {
    return { ...this.progress };
  }

  getResults(): SearchResult[] {
    return [...this.results];
  }

  getSearchTime(): number {
    return this.startTime > 0 ? (Date.now() - this.startTime) / 1000 : 0;
  }

  isSearchActive(): boolean {
    return this.isActive;
  }
}