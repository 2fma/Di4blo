import { SearchService } from "./searchService";
import { storage } from "./storage";
import { getSiteCategories } from "./sites";

class SearchManager {
  private activeSearches = new Map<string, SearchService>();

  async startSearch(username: string): Promise<{ searchId: string; search: any }> {
    // Create search record in storage
    const search = await storage.createSearch({ username });
    const searchId = search.id;
    
    // Create and start search service
    const searchService = new SearchService(searchId, username);
    this.activeSearches.set(searchId, searchService);

    // Set up event listeners
    searchService.on("progress", async (progress) => {
      await storage.updateSearch(searchId, {
        foundCount: progress.foundCount.toString(),
        totalSites: progress.total.toString()
      });
    });

    searchService.on("result", async (result) => {
      const currentSearch = await storage.getSearch(searchId);
      if (currentSearch) {
        const updatedResults = [...(currentSearch.results as any[]), result];
        await storage.updateSearch(searchId, {
          results: updatedResults
        });
      }
    });

    searchService.on("status", async (status) => {
      const updates: any = { status };
      if (status === "completed" || status === "failed") {
        updates.completedAt = new Date();
        this.activeSearches.delete(searchId);
      }
      await storage.updateSearch(searchId, updates);
    });

    // Start the search in background
    searchService.startSearch().catch(async (error) => {
      console.error("Search failed:", error);
      await storage.updateSearch(searchId, {
        status: "failed",
        completedAt: new Date()
      });
      this.activeSearches.delete(searchId);
    });

    return { searchId, search };
  }

  getSearchProgress(searchId: string) {
    const searchService = this.activeSearches.get(searchId);
    if (!searchService) {
      return null;
    }
    return {
      progress: searchService.getProgress(),
      results: searchService.getResults(),
      searchTime: searchService.getSearchTime(),
      isActive: searchService.isSearchActive()
    };
  }

  stopSearch(searchId: string): boolean {
    const searchService = this.activeSearches.get(searchId);
    if (searchService) {
      searchService.stopSearch();
      this.activeSearches.delete(searchId);
      return true;
    }
    return false;
  }

  getActiveSearches(): string[] {
    return Array.from(this.activeSearches.keys());
  }

  getSiteCategories() {
    return getSiteCategories();
  }
}

export const searchManager = new SearchManager();