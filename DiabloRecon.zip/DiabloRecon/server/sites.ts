export interface SiteConfig {
  url: string;
  category: string;
  errorIndicators?: string[];
}

export const sites: Record<string, SiteConfig> = {
  // Social Media Platforms
  "Facebook": {
    url: "https://www.facebook.com/{}",
    category: "Social Media",
    errorIndicators: ["This profile could not be found", "Sorry, this user was not found"]
  },
  "Twitter": {
    url: "https://twitter.com/{}",
    category: "Social Media",
    errorIndicators: ["This account doesn't exist", "Account suspended"]
  },
  "Instagram": {
    url: "https://www.instagram.com/{}",
    category: "Social Media",
    errorIndicators: ["Sorry, this page isn't available", "User not found"]
  },
  "YouTube": {
    url: "https://www.youtube.com/{}",
    category: "Video",
    errorIndicators: ["This channel doesn't exist", "404 Not Found"]
  },
  "TikTok": {
    url: "https://www.tiktok.com/@{}",
    category: "Social Media",
    errorIndicators: ["Couldn't find this account", "User not found"]
  },
  "Reddit": {
    url: "https://www.reddit.com/user/{}",
    category: "Social Media",
    errorIndicators: ["Sorry, nobody on Reddit goes by that name", "user does not exist"]
  },
  
  // Professional & Development Platforms
  "GitHub": {
    url: "https://www.github.com/{}",
    category: "Development",
    errorIndicators: ["Not Found", "404"]
  },
  "GitLab": {
    url: "https://gitlab.com/{}",
    category: "Development",
    errorIndicators: ["The profile was either removed", "404"]
  },
  "Bitbucket": {
    url: "https://bitbucket.org/{}",
    category: "Development",
    errorIndicators: ["404", "Not found"]
  },
  "Stack Overflow": {
    url: "https://stackoverflow.com/users/{}/{}",
    category: "Development",
    errorIndicators: ["User not found", "404"]
  },
  "LinkedIn": {
    url: "https://www.linkedin.com/in/{}",
    category: "Professional",
    errorIndicators: ["This profile was not found", "Member not found"]
  },
  
  // Creative Platforms
  "Behance": {
    url: "https://www.behance.net/{}",
    category: "Creative",
    errorIndicators: ["404", "User not found"]
  },
  "Dribbble": {
    url: "https://dribbble.com/{}",
    category: "Creative",
    errorIndicators: ["Sorry, we can't find that user", "404"]
  },
  "DeviantArt": {
    url: "https://{}.deviantart.com",
    category: "Creative",
    errorIndicators: ["404", "User not found"]
  },
  "Pinterest": {
    url: "https://www.pinterest.com/{}",
    category: "Creative",
    errorIndicators: ["Sorry, we searched everywhere", "User not found"]
  },
  
  // Gaming Platforms
  "Steam": {
    url: "https://steamcommunity.com/id/{}",
    category: "Gaming",
    errorIndicators: ["The specified profile could not be found", "404"]
  },
  "Twitch": {
    url: "https://www.twitch.tv/{}",
    category: "Gaming",
    errorIndicators: ["Sorry. Unless you've got a time machine", "404"]
  },
  "Discord": {
    url: "https://discord.com/users/{}",
    category: "Gaming",
    errorIndicators: ["User not found", "404"]
  },
  
  // Music & Media
  "Spotify": {
    url: "https://open.spotify.com/user/{}",
    category: "Music",
    errorIndicators: ["User not found", "404"]
  },
  "SoundCloud": {
    url: "https://soundcloud.com/{}",
    category: "Music",
    errorIndicators: ["We can't find that user", "404"]
  },
  "Last.fm": {
    url: "https://www.last.fm/user/{}",
    category: "Music",
    errorIndicators: ["No user with that name was found", "404"]
  },
  
  // Blogging & Writing
  "Medium": {
    url: "https://medium.com/@{}",
    category: "Blogging",
    errorIndicators: ["Page not found", "404"]
  },
  "Tumblr": {
    url: "https://{}.tumblr.com/",
    category: "Blogging",
    errorIndicators: ["There's nothing here", "404"]
  },
  "WordPress": {
    url: "https://{}.wordpress.com",
    category: "Blogging",
    errorIndicators: ["doesn't exist", "404"]
  },
  
  // Learning & Education
  "Khan Academy": {
    url: "https://www.khanacademy.org/profile/{}",
    category: "Education",
    errorIndicators: ["Profile not found", "404"]
  },
  "Coursera": {
    url: "https://www.coursera.org/user/{}",
    category: "Education",
    errorIndicators: ["User not found", "404"]
  },
  "Codecademy": {
    url: "https://www.codecademy.com/profiles/{}",
    category: "Education",
    errorIndicators: ["Profile not found", "404"]
  },
  "LeetCode": {
    url: "https://leetcode.com/{}",
    category: "Education",
    errorIndicators: ["User does not exist", "404"]
  },
  "HackerRank": {
    url: "https://hackerrank.com/{}",
    category: "Education",
    errorIndicators: ["Profile not found", "404"]
  },
  
  // E-commerce & Marketplace
  "eBay": {
    url: "https://www.ebay.com/usr/{}",
    category: "E-commerce",
    errorIndicators: ["User not found", "404"]
  },
  "Fiverr": {
    url: "https://www.fiverr.com/{}",
    category: "E-commerce",
    errorIndicators: ["User not found", "404"]
  },
  
  // Forums & Communities
  "Quora": {
    url: "https://www.quora.com/profile/{}",
    category: "Forums",
    errorIndicators: ["Profile not found", "404"]
  },
  "Wikipedia": {
    url: "https://en.wikipedia.org/wiki/User:{}",
    category: "Reference",
    errorIndicators: ["Wikipedia does not have a", "404"]
  },
  
  // Misc Platforms
  "Gravatar": {
    url: "https://gravatar.com/{}",
    category: "Identity",
    errorIndicators: ["Profile not found", "404"]
  },
  "Keybase": {
    url: "https://keybase.io/{}",
    category: "Security",
    errorIndicators: ["User not found", "404"]
  },
  "Replit": {
    url: "https://replit.com/@{}",
    category: "Development",
    errorIndicators: ["User not found", "404"]
  },
  "Patreon": {
    url: "https://www.patreon.com/{}",
    category: "Creative",
    errorIndicators: ["Page not found", "404"]
  },
  "Venmo": {
    url: "https://account.venmo.com/u/{}",
    category: "Finance",
    errorIndicators: ["User not found", "404"]
  },
  "Flickr": {
    url: "https://www.flickr.com/people/{}",
    category: "Photos",
    errorIndicators: ["User not found", "404"]
  },
  "Vimeo": {
    url: "https://vimeo.com/{}",
    category: "Video",
    errorIndicators: ["Page not found", "404"]
  },
  "Goodreads": {
    url: "https://www.goodreads.com/{}",
    category: "Books",
    errorIndicators: ["Page not found", "404"]
  },
  "Wattpad": {
    url: "https://www.wattpad.com/user/{}",
    category: "Writing",
    errorIndicators: ["User not found", "404"]
  },
  "BuyMeACoffee": {
    url: "https://www.buymeacoffee.com/{}",
    category: "Creative",
    errorIndicators: ["Page not found", "404"]
  },
  "Linktree": {
    url: "https://linktr.ee/{}",
    category: "Social",
    errorIndicators: ["Page not found", "404"]
  },
  "ProductHunt": {
    url: "https://www.producthunt.com/@{}",
    category: "Tech",
    errorIndicators: ["Page not found", "404"]
  },
  "Unsplash": {
    url: "https://unsplash.com/@{}",
    category: "Photos",
    errorIndicators: ["User not found", "404"]
  },
  "TradingView": {
    url: "https://www.tradingview.com/u/{}",
    category: "Finance",
    errorIndicators: ["User not found", "404"]
  },
  "Trello": {
    url: "https://trello.com/{}",
    category: "Productivity",
    errorIndicators: ["Member not found", "404"]
  },
  "Chess": {
    url: "https://www.chess.com/member/{}",
    category: "Gaming",
    errorIndicators: ["Member not found", "404"]
  },
  "Lichess": {
    url: "https://lichess.org/@/{}",
    category: "Gaming",
    errorIndicators: ["User not found", "404"]
  },
  "Scratch": {
    url: "https://scratch.mit.edu/users/{}",
    category: "Education",
    errorIndicators: ["User not found", "404"]
  },
  "MyAnimeList": {
    url: "https://myanimelist.net/profile/{}",
    category: "Entertainment",
    errorIndicators: ["Profile not found", "404"]
  },
  "freeCodeCamp": {
    url: "https://www.freecodecamp.org/{}",
    category: "Education",
    errorIndicators: ["User not found", "404"]
  },
  "Anilist": {
    url: "https://anilist.co/user/{}",
    category: "Entertainment",
    errorIndicators: ["User not found", "404"]
  },
  "TryHackMe": {
    url: "https://tryhackme.com/p/{}",
    category: "Security",
    errorIndicators: ["User not found", "404"]
  },
  "Instructables": {
    url: "https://www.instructables.com/member/{}",
    category: "DIY",
    errorIndicators: ["Member not found", "404"]
  },
  "Imgur": {
    url: "https://imgur.com/user/{}",
    category: "Images",
    errorIndicators: ["User not found", "404"]
  },
  "SlideShare": {
    url: "https://www.slideshare.net/{}",
    category: "Business",
    errorIndicators: ["User not found", "404"]
  }
};

// Common error indicators that apply to most sites
export const globalErrorIndicators = [
  "This profile could not be found",
  "Sorry, this user was not found", 
  "Page Not Found",
  "the profile was either removed",
  "The specified profile could not be found",
  "doesn't exist",
  "This page doesn't exist",
  "404 Not Found",
  "Sorry, nobody on Reddit goes by that name",
  "The person may have been banned or the username is incorrect",
  "Some error occured while loading page for you. Please try again",
  "No longer a registered user",
  "No user ID specified or user does not exist!",
  "user does not exist",
  "User not found.",
  "An error was encountered while processing your request",
  "Sorry, the page you were looking for doesn't exist",
  "Wikipedia does not have a",
  "We could not find the page you were looking for",
  "Not Found!",
  "statusMsg:\"\",\"needFix\"",
  "Sorry, unless you've got a time machine",
  "This account doesn't exist",
  "Sorry, this page isn't available",
  "Couldn't find this account",
  "We can't find that user",
  "Sorry, we searched everywhere",
  "There's nothing here",
  "Profile not found",
  "Member not found",
  "Page not found"
];

// User agents to rotate for requests
export const userAgents = [
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/116.0",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0"
];

export function getSiteCategories(): Record<string, { total: number; found: number }> {
  const categories: Record<string, { total: number; found: number }> = {};
  
  Object.values(sites).forEach(site => {
    if (!categories[site.category]) {
      categories[site.category] = { total: 0, found: 0 };
    }
    categories[site.category].total++;
  });
  
  return categories;
}