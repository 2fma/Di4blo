import { type User, type InsertUser, type Search, type InsertSearch } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Search operations
  createSearch(search: InsertSearch): Promise<Search>;
  getSearch(id: string): Promise<Search | undefined>;
  updateSearch(id: string, updates: Partial<Search>): Promise<Search>;
  getSearchesByUsername(username: string): Promise<Search[]>;
  deleteSearch(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private searches: Map<string, Search>;

  constructor() {
    this.users = new Map();
    this.searches = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createSearch(searchData: InsertSearch): Promise<Search> {
    const id = randomUUID();
    const search: Search = {
      id,
      status: "pending",
      foundCount: "0",
      totalSites: "0",
      results: [],
      createdAt: new Date(),
      completedAt: null,
      ...searchData,
    };
    this.searches.set(id, search);
    return search;
  }

  async getSearch(id: string): Promise<Search | undefined> {
    return this.searches.get(id);
  }

  async updateSearch(id: string, updates: Partial<Search>): Promise<Search> {
    const search = this.searches.get(id);
    if (!search) {
      throw new Error("Search not found");
    }
    
    const updatedSearch = { ...search, ...updates };
    this.searches.set(id, updatedSearch);
    return updatedSearch;
  }

  async getSearchesByUsername(username: string): Promise<Search[]> {
    return Array.from(this.searches.values()).filter(
      search => search.username === username
    );
  }

  async deleteSearch(id: string): Promise<void> {
    if (!this.searches.has(id)) {
      throw new Error("Search not found");
    }
    this.searches.delete(id);
  }
}

export const storage = new MemStorage();
