import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const searches = pgTable("searches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull(),
  status: text("status", { enum: ["pending", "running", "completed", "failed", "cancelled"] }).notNull().default("pending"),
  foundCount: text("found_count").default("0"),
  totalSites: text("total_sites").default("0"),
  results: jsonb("results").default([]),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertSearchSchema = createInsertSchema(searches).pick({
  username: true,
});

// Search result types
export const searchResultSchema = z.object({
  site: z.string(),
  url: z.string(),
  status: z.enum(["found", "not_found", "error", "checking"]),
  category: z.string().optional(),
  responseTime: z.number().optional(),
});

export const searchProgressSchema = z.object({
  current: z.number(),
  total: z.number(),
  foundCount: z.number(),
  currentSite: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Search = typeof searches.$inferSelect;
export type InsertSearch = z.infer<typeof insertSearchSchema>;
export type SearchResult = z.infer<typeof searchResultSchema>;
export type SearchProgress = z.infer<typeof searchProgressSchema>;
