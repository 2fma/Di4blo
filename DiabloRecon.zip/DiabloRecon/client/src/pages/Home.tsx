import { useState } from "react";
import SearchForm, { SearchOptions } from "@/components/SearchForm";
import ProgressIndicator from "@/components/ProgressIndicator";
import ResultsTable from "@/components/ResultsTable";
import FilterSidebar from "@/components/FilterSidebar";
import ExportPanel from "@/components/ExportPanel";
import StatsDashboard from "@/components/StatsDashboard";
import ThemeToggle from "@/components/ThemeToggle";
import { useSearch } from "@/hooks/useSearch";
import { useCategories } from "@/hooks/useCategories";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Terminal, Github, Twitter, Shield, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Home() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const { categories, loading: categoriesLoading } = useCategories();
  
  const {
    currentSearch,
    isSearching,
    searchProgress,
    results,
    startSearch,
    stopSearch,
    exportTxt,
    error,
    searchTime,
  } = useSearch();

  const handleSearch = async (username: string, options: SearchOptions) => {
    console.log(`Starting search for: ${username}`, options);
    await startSearch(username);
  };

  const handleCategoryChange = (categories: string[]) => {
    setSelectedCategories(categories);
    console.log('Categories filter changed:', categories);
  };

  const handleClearFilters = () => {
    setSelectedCategories([]);
    console.log('Filters cleared');
  };

  const handleExport = async (format: 'txt' | 'pdf') => {
    console.log(`Export triggered: ${format}`);
    if (format === 'txt') {
      await exportTxt();
    }
    // PDF export can be implemented later
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Terminal className="h-8 w-8 text-primary" />
                <div>
                  <h1 className="text-xl font-bold text-foreground">Diablo Recon</h1>
                  <p className="text-sm text-muted-foreground">OSINT Username Search</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Shield className="h-4 w-4" />
                  <span>Professional OSINT Tool</span>
                </div>
              </div>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <div className="space-y-6">
          {/* Error Alert */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Search Form */}
          <div className="flex justify-center">
            <SearchForm onSearch={handleSearch} isSearching={isSearching} />
          </div>

          {/* Search Progress */}
          {(isSearching || results.length > 0) && (
            <ProgressIndicator progress={searchProgress} isActive={isSearching} />
          )}

          {/* Statistics Dashboard */}
          {results.length > 0 && (
            <StatsDashboard 
              results={results} 
              searchTime={searchTime} 
              isActive={isSearching} 
            />
          )}

          {/* Results Section */}
          {results.length > 0 && (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Sidebar */}
              <div className="lg:col-span-1 space-y-6">
                {!categoriesLoading && (
                  <FilterSidebar
                    categories={categories}
                    selectedCategories={selectedCategories}
                    onCategoryChange={handleCategoryChange}
                    onClearFilters={handleClearFilters}
                  />
                )}
                <ExportPanel
                  results={results}
                  username={currentSearch}
                  onExport={handleExport}
                />
              </div>

              {/* Main Results */}
              <div className="lg:col-span-3">
                <ResultsTable results={results} username={currentSearch} />
              </div>
            </div>
          )}

          {/* Welcome Message */}
          {!isSearching && results.length === 0 && (
            <Card className="max-w-4xl mx-auto">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="h-5 w-5 text-primary" />
                  Welcome to Diablo Recon
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Professional OSINT reconnaissance tool for finding user profiles across social media and online platforms. 
                  Enter a username above to begin searching across hundreds of sites.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Github className="h-4 w-4 text-primary" />
                    <span>Development platforms</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Twitter className="h-4 w-4 text-primary" />
                    <span>Social media networks</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-primary" />
                    <span>Professional networks</span>
                  </div>
                </div>
                <div className="bg-muted/50 rounded-lg p-4 text-sm text-muted-foreground">
                  <strong className="text-foreground">Note:</strong> This tool is for legitimate OSINT research purposes only. 
                  Always respect privacy and terms of service of the platforms being searched.
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}