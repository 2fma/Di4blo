import { SearchResult, SearchProgress } from "@shared/schema";

export interface SearchResponse {
  success: boolean;
  searchId: string;
  search: any;
}

export interface SearchStatusResponse {
  success: boolean;
  search: any;
  liveProgress?: {
    progress: SearchProgress;
    results: SearchResult[];
    searchTime: number;
    isActive: boolean;
  };
}

export interface CategoriesResponse {
  success: boolean;
  categories: Record<string, { total: number; found: number }>;
}

class ApiClient {
  private baseUrl = "";

  async startSearch(username: string): Promise<SearchResponse> {
    const response = await fetch("/api/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.json();
  }

  async getSearchStatus(searchId: string): Promise<SearchStatusResponse> {
    const response = await fetch(`/api/search/${searchId}`);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.json();
  }

  async stopSearch(searchId: string): Promise<{ success: boolean; stopped: boolean }> {
    const response = await fetch(`/api/search/${searchId}/stop`, {
      method: "POST",
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.json();
  }

  async getCategories(): Promise<CategoriesResponse> {
    const response = await fetch("/api/categories");

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.json();
  }

  async exportTxt(searchId: string): Promise<void> {
    const response = await fetch(`/api/search/${searchId}/export/txt`);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.style.display = "none";
    a.href = url;
    a.download = response.headers.get("Content-Disposition")?.split("filename=")[1]?.replace(/"/g, "") || "results.txt";
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  async getUserSearches(username: string): Promise<{ success: boolean; searches: any[] }> {
    const response = await fetch(`/api/searches/${username}`);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.json();
  }
}

export const apiClient = new ApiClient();