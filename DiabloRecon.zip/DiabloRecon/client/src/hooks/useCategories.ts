import { useState, useEffect } from "react";
import { apiClient } from "@/lib/api";

export interface CategoryData {
  [category: string]: {
    total: number;
    found: number;
  };
}

export function useCategories() {
  const [categories, setCategories] = useState<CategoryData>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await apiClient.getCategories();
        setCategories(response.categories);
      } catch (err) {
        console.error("Error fetching categories:", err);
        setError(err instanceof Error ? err.message : "Failed to fetch categories");
        
        // Fallback to empty categories
        setCategories({});
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  return { categories, loading, error };
}