import { useState, useEffect, useCallback } from "react";
import { SearchResult, SearchProgress } from "@shared/schema";
import { apiClient } from "@/lib/api";

export interface UseSearchReturn {
  currentSearch: string;
  isSearching: boolean;
  searchProgress: SearchProgress;
  results: SearchResult[];
  searchId: string | null;
  startSearch: (username: string) => Promise<void>;
  stopSearch: () => Promise<void>;
  exportTxt: () => Promise<void>;
  error: string | null;
  searchTime: number;
}

export function useSearch(): UseSearchReturn {
  const [currentSearch, setCurrentSearch] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchProgress, setSearchProgress] = useState<SearchProgress>({
    current: 0,
    total: 0,
    foundCount: 0,
  });
  const [results, setResults] = useState<SearchResult[]>([]);
  const [searchId, setSearchId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [searchTime, setSearchTime] = useState(0);
  const [pollInterval, setPollInterval] = useState<NodeJS.Timeout | null>(null);

  const startSearch = useCallback(async (username: string) => {
    try {
      setError(null);
      setCurrentSearch(username);
      setIsSearching(true);
      setResults([]);
      setSearchTime(0);
      setSearchProgress({ current: 0, total: 0, foundCount: 0 });

      console.log(`Starting search for username: ${username}`);
      
      const response = await apiClient.startSearch(username);
      setSearchId(response.searchId);

      // Start polling for updates
      const interval = setInterval(async () => {
        try {
          const statusResponse = await apiClient.getSearchStatus(response.searchId);
          
          if (statusResponse.liveProgress) {
            setSearchProgress(statusResponse.liveProgress.progress);
            setResults(statusResponse.liveProgress.results);
            setSearchTime(statusResponse.liveProgress.searchTime);
            setIsSearching(statusResponse.liveProgress.isActive);

            // Stop polling when search is complete
            if (!statusResponse.liveProgress.isActive) {
              clearInterval(interval);
              setPollInterval(null);
            }
          } else {
            // Fall back to stored search data
            const search = statusResponse.search;
            if (search) {
              setResults(search.results || []);
              setSearchProgress({
                current: parseInt(search.totalSites) || 0,
                total: parseInt(search.totalSites) || 0,
                foundCount: parseInt(search.foundCount) || 0,
              });
              
              if (search.status === "completed" || search.status === "failed" || search.status === "cancelled") {
                setIsSearching(false);
                clearInterval(interval);
                setPollInterval(null);
              }
            }
          }
        } catch (err) {
          console.error("Error polling search status:", err);
        }
      }, 1000); // Poll every second

      setPollInterval(interval);

    } catch (err) {
      console.error("Error starting search:", err);
      setError(err instanceof Error ? err.message : "Failed to start search");
      setIsSearching(false);
    }
  }, []);

  const stopSearch = useCallback(async () => {
    if (!searchId) return;

    try {
      await apiClient.stopSearch(searchId);
      setIsSearching(false);
      
      if (pollInterval) {
        clearInterval(pollInterval);
        setPollInterval(null);
      }
      
      console.log("Search stopped");
    } catch (err) {
      console.error("Error stopping search:", err);
      setError(err instanceof Error ? err.message : "Failed to stop search");
    }
  }, [searchId, pollInterval]);

  const exportTxt = useCallback(async () => {
    if (!searchId) return;

    try {
      await apiClient.exportTxt(searchId);
      console.log("TXT export completed");
    } catch (err) {
      console.error("Error exporting TXT:", err);
      setError(err instanceof Error ? err.message : "Failed to export results");
    }
  }, [searchId]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (pollInterval) {
        clearInterval(pollInterval);
      }
    };
  }, [pollInterval]);

  return {
    currentSearch,
    isSearching,
    searchProgress,
    results,
    searchId,
    startSearch,
    stopSearch,
    exportTxt,
    error,
    searchTime,
  };
}