import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Clock, AlertCircle, Globe, Timer } from "lucide-react";
import { SearchResult } from "@shared/schema";

interface StatsDashboardProps {
  results: SearchResult[];
  searchTime?: number;
  isActive?: boolean;
}

export default function StatsDashboard({ results, searchTime, isActive = false }: StatsDashboardProps) {
  const foundCount = results.filter(r => r.status === "found").length;
  const notFoundCount = results.filter(r => r.status === "not_found").length;
  const checkingCount = results.filter(r => r.status === "checking").length;
  const errorCount = results.filter(r => r.status === "error").length;
  const totalChecked = results.length;
  
  const successRate = totalChecked > 0 ? (foundCount / totalChecked) * 100 : 0;
  
  // Calculate average response time from found results
  const responseTimes = results
    .filter(r => r.status === "found" && r.responseTime)
    .map(r => r.responseTime!);
  const avgResponseTime = responseTimes.length > 0 
    ? responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length 
    : 0;

  const formatTime = (seconds: number) => {
    if (seconds < 60) return `${seconds.toFixed(1)}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds.toFixed(0)}s`;
  };

  const stats = [
    {
      title: "Found",
      value: foundCount,
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-950",
      testId: "stat-found",
    },
    {
      title: "Not Found", 
      value: notFoundCount,
      icon: XCircle,
      color: "text-red-600",
      bgColor: "bg-red-50 dark:bg-red-950",
      testId: "stat-not-found",
    },
    {
      title: "Checking",
      value: checkingCount,
      icon: Clock,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50 dark:bg-yellow-950",
      testId: "stat-checking",
    },
    {
      title: "Errors",
      value: errorCount,
      icon: AlertCircle,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      testId: "stat-errors",
    },
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.title} className={stat.bgColor}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                <p className="text-2xl font-bold" data-testid={stat.testId}>
                  {stat.value}
                </p>
              </div>
              <stat.icon className={`h-8 w-8 ${stat.color}`} />
            </div>
          </CardContent>
        </Card>
      ))}
      
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
              <p className="text-2xl font-bold" data-testid="stat-success-rate">
                {successRate.toFixed(1)}%
              </p>
            </div>
            <Globe className="h-8 w-8 text-primary" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Search Time</p>
              <p className="text-2xl font-bold" data-testid="stat-search-time">
                {searchTime ? formatTime(searchTime) : "0s"}
              </p>
              {isActive && (
                <Badge variant="outline" className="text-xs mt-1">
                  <div className="animate-pulse w-2 h-2 bg-primary rounded-full mr-1" />
                  Running
                </Badge>
              )}
            </div>
            <Timer className="h-8 w-8 text-muted-foreground" />
          </div>
        </CardContent>
      </Card>

      {avgResponseTime > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Response</p>
                <p className="text-2xl font-bold" data-testid="stat-avg-response">
                  {avgResponseTime.toFixed(0)}ms
                </p>
              </div>
              <Clock className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Sites</p>
              <p className="text-2xl font-bold" data-testid="stat-total-sites">
                {totalChecked}
              </p>
            </div>
            <Globe className="h-8 w-8 text-muted-foreground" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}