import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Filter, RefreshCw } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface CategoryCounts {
  [category: string]: {
    total: number;
    found: number;
  };
}

interface FilterSidebarProps {
  categories: CategoryCounts;
  selectedCategories: string[];
  onCategoryChange: (categories: string[]) => void;
  onClearFilters: () => void;
}

const categoryIcons: { [key: string]: string } = {
  "Social Media": "👥",
  "Development": "💻",
  "Gaming": "🎮",
  "Professional": "💼",
  "Forums": "💬",
  "Dating": "💕",
  "Shopping": "🛒",
  "Music": "🎵",
  "Video": "📹",
  "Photos": "📸",
  "Business": "🏢",
  "News": "📰",
  "Education": "🎓",
  "Finance": "💰",
  "Health": "🏥",
  "Travel": "✈️",
  "Art": "🎨",
  "Tech": "⚙️",
  "Sports": "⚽",
  "Adult": "🔞",
};

export default function FilterSidebar({ 
  categories, 
  selectedCategories, 
  onCategoryChange, 
  onClearFilters 
}: FilterSidebarProps) {
  const [isOpen, setIsOpen] = useState(true);

  const handleCategoryToggle = (category: string, checked: boolean) => {
    if (checked) {
      onCategoryChange([...selectedCategories, category]);
    } else {
      onCategoryChange(selectedCategories.filter(c => c !== category));
    }
    console.log(`Category ${category} ${checked ? 'enabled' : 'disabled'}`);
  };

  const handleSelectAll = () => {
    onCategoryChange(Object.keys(categories));
    console.log('All categories selected');
  };

  const handleClearAll = () => {
    onClearFilters();
    console.log('All filters cleared');
  };

  const sortedCategories = Object.entries(categories).sort(([a], [b]) => a.localeCompare(b));
  const hasFilters = selectedCategories.length > 0;

  return (
    <Card className="w-full max-w-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Filter className="h-4 w-4" />
          Site Categories
          {hasFilters && (
            <Badge variant="secondary" className="text-xs">
              {selectedCategories.length}
            </Badge>
          )}
        </CardTitle>
        <div className="flex gap-2">
          <Button 
            size="sm" 
            variant="outline" 
            onClick={handleSelectAll}
            className="text-xs h-7"
            data-testid="button-select-all"
          >
            Select All
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={handleClearAll}
            className="text-xs h-7"
            data-testid="button-clear-filters"
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            Clear
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <Collapsible open={isOpen} onOpenChange={setIsOpen}>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="w-full justify-between text-xs mb-2">
              Categories ({sortedCategories.length})
              <span className={`transition-transform ${isOpen ? 'rotate-180' : ''}`}>▼</span>
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {sortedCategories.map(([category, counts]) => {
                const isSelected = selectedCategories.includes(category);
                const foundPercentage = counts.total > 0 ? (counts.found / counts.total) * 100 : 0;
                
                return (
                  <div
                    key={category}
                    className="flex items-center space-x-2 p-2 rounded-md hover-elevate"
                    data-testid={`filter-category-${category}`}
                  >
                    <Checkbox
                      id={category}
                      checked={isSelected}
                      onCheckedChange={(checked) => handleCategoryToggle(category, Boolean(checked))}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="text-xs">{categoryIcons[category] || "📁"}</span>
                        <span className="text-sm truncate">{category}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs px-1 py-0">
                          {counts.total}
                        </Badge>
                        {counts.found > 0 && (
                          <Badge variant="outline" className="text-xs px-1 py-0 text-green-600 border-green-600">
                            {counts.found} found
                          </Badge>
                        )}
                        <div className="text-xs text-muted-foreground">
                          {foundPercentage.toFixed(0)}%
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}