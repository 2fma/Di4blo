import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Globe } from "lucide-react";
import { SearchProgress } from "@shared/schema";

interface ProgressIndicatorProps {
  progress: SearchProgress;
  isActive?: boolean;
}

export default function ProgressIndicator({ progress, isActive = false }: ProgressIndicatorProps) {
  const percentage = progress.total > 0 ? (progress.current / progress.total) * 100 : 0;
  const remainingSites = progress.total - progress.current;

  return (
    <Card className="w-full">
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Search Progress</span>
              {isActive && (
                <Badge variant="outline" className="text-xs">
                  <div className="animate-pulse w-2 h-2 bg-primary rounded-full mr-1" />
                  Active
                </Badge>
              )}
            </div>
            <div className="text-right text-sm text-muted-foreground">
              {progress.current} / {progress.total} sites
            </div>
          </div>

          <div className="space-y-2">
            <Progress 
              value={percentage} 
              className="h-2"
              data-testid="progress-search"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{Math.round(percentage)}% complete</span>
              <span>{remainingSites} remaining</span>
            </div>
          </div>

          {progress.currentSite && (
            <div className="flex items-center gap-2 text-sm">
              <Clock className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Checking:</span>
              <span className="font-mono font-medium" data-testid="text-current-site">
                {progress.currentSite}
              </span>
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t">
            <div className="text-sm">
              <span className="text-muted-foreground">Found profiles:</span>
              <span className="ml-2 font-semibold text-primary" data-testid="text-found-count">
                {progress.foundCount}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}