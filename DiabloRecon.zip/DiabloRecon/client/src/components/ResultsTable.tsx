import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ExternalLink, Search, Clock, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { SearchResult } from "@shared/schema";

interface ResultsTableProps {
  results: SearchResult[];
  username: string;
}

const getStatusIcon = (status: SearchResult["status"]) => {
  switch (status) {
    case "found":
      return <CheckCircle className="h-3 w-3 text-green-500" />;
    case "not_found":
      return <XCircle className="h-3 w-3 text-red-500" />;
    case "checking":
      return <Clock className="h-3 w-3 text-yellow-500 animate-spin" />;
    case "error":
      return <AlertCircle className="h-3 w-3 text-destructive" />;
    default:
      return null;
  }
};

const getStatusBadge = (status: SearchResult["status"]) => {
  switch (status) {
    case "found":
      return <Badge variant="outline" className="text-green-600 border-green-600">Found</Badge>;
    case "not_found":
      return <Badge variant="outline" className="text-red-600 border-red-600">Not Found</Badge>;
    case "checking":
      return <Badge variant="outline" className="text-yellow-600 border-yellow-600">Checking</Badge>;
    case "error":
      return <Badge variant="destructive">Error</Badge>;
    default:
      return null;
  }
};

export default function ResultsTable({ results, username }: ResultsTableProps) {
  const [searchFilter, setSearchFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState<SearchResult["status"] | "all">("all");

  const filteredResults = results.filter(result => {
    const matchesSearch = result.site.toLowerCase().includes(searchFilter.toLowerCase()) ||
                         (result.category && result.category.toLowerCase().includes(searchFilter.toLowerCase()));
    const matchesStatus = statusFilter === "all" || result.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const foundResults = results.filter(r => r.status === "found");
  const checkingResults = results.filter(r => r.status === "checking");

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Results for "{username}"
          </div>
          <div className="flex gap-2 text-sm">
            <Badge variant="outline" className="text-green-600 border-green-600">
              {foundResults.length} Found
            </Badge>
            <Badge variant="outline" className="text-muted-foreground">
              {results.length} Total
            </Badge>
          </div>
        </CardTitle>
        
        <div className="flex gap-2 flex-wrap">
          <Input
            placeholder="Filter by site or category..."
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="max-w-xs"
            data-testid="input-filter-sites"
          />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-1 rounded-md border border-input bg-background text-sm"
            data-testid="select-status-filter"
          >
            <option value="all">All Status</option>
            <option value="found">Found</option>
            <option value="not_found">Not Found</option>
            <option value="checking">Checking</option>
            <option value="error">Error</option>
          </select>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="max-h-96 overflow-y-auto">
          <div className="space-y-1 p-4">
            {filteredResults.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {results.length === 0 ? "No results yet" : "No results match your filters"}
              </div>
            ) : (
              filteredResults.map((result, index) => (
                <div
                  key={`${result.site}-${index}`}
                  className="flex items-center justify-between p-3 rounded-lg border hover-elevate"
                  data-testid={`row-result-${index}`}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {getStatusIcon(result.status)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">{result.site}</span>
                        {result.category && (
                          <Badge variant="secondary" className="text-xs">
                            {result.category}
                          </Badge>
                        )}
                      </div>
                      {result.status === "found" && (
                        <span className="text-xs text-muted-foreground font-mono truncate block">
                          {result.url}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {getStatusBadge(result.status)}
                    {result.status === "found" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => window.open(result.url, "_blank")}
                        data-testid={`button-open-${index}`}
                      >
                        <ExternalLink className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}