import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Search, Settings } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface SearchFormProps {
  onSearch: (username: string, options: SearchOptions) => void;
  isSearching?: boolean;
}

export interface SearchOptions {
  quietMode: boolean;
  verboseErrors: boolean;
  exportPdf: boolean;
}

export default function SearchForm({ onSearch, isSearching = false }: SearchFormProps) {
  const [username, setUsername] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [options, setOptions] = useState<SearchOptions>({
    quietMode: false,
    verboseErrors: false,
    exportPdf: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      console.log(`Starting search for username: ${username}`);
      onSearch(username.trim(), options);
    }
  };

  const updateOption = (key: keyof SearchOptions, value: boolean) => {
    setOptions(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-primary">
          <Search className="h-5 w-5" />
          Diablo Recon - Username Search
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username" className="text-sm font-medium">
              Username to Search
            </Label>
            <Input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter username to search across platforms"
              className="font-mono"
              data-testid="input-username"
              disabled={isSearching}
            />
          </div>

          <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
            <CollapsibleTrigger asChild>
              <Button 
                type="button" 
                variant="ghost" 
                size="sm" 
                className="w-full justify-start"
                data-testid="button-advanced-options"
              >
                <Settings className="h-4 w-4 mr-2" />
                Advanced Options
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-3 pt-3">
              <div className="grid grid-cols-1 gap-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="quiet"
                    checked={options.quietMode}
                    onCheckedChange={(checked) => updateOption("quietMode", Boolean(checked))}
                    data-testid="checkbox-quiet-mode"
                  />
                  <Label htmlFor="quiet" className="text-sm">
                    Quiet mode (hide not found results)
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="verbose"
                    checked={options.verboseErrors}
                    onCheckedChange={(checked) => updateOption("verboseErrors", Boolean(checked))}
                    data-testid="checkbox-verbose-errors"
                  />
                  <Label htmlFor="verbose" className="text-sm">
                    Verbose error reporting
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="pdf"
                    checked={options.exportPdf}
                    onCheckedChange={(checked) => updateOption("exportPdf", Boolean(checked))}
                    data-testid="checkbox-export-pdf"
                  />
                  <Label htmlFor="pdf" className="text-sm">
                    Generate PDF report after search
                  </Label>
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Button 
            type="submit" 
            className="w-full" 
            disabled={!username.trim() || isSearching}
            data-testid="button-start-search"
          >
            {isSearching ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Searching...
              </>
            ) : (
              <>
                <Search className="h-4 w-4 mr-2" />
                Start Search
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}