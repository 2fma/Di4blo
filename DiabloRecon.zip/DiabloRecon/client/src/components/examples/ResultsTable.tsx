import ResultsTable from '../ResultsTable';

export default function ResultsTableExample() {
  // todo: remove mock functionality
  const mockResults = [
    {
      site: "GitHub",
      url: "https://github.com/testuser",
      status: "found" as const,
      category: "Development",
      responseTime: 245,
    },
    {
      site: "Twitter",
      url: "https://twitter.com/testuser",
      status: "found" as const,
      category: "Social Media",
      responseTime: 189,
    },
    {
      site: "Instagram",
      url: "",
      status: "not_found" as const,
      category: "Social Media",
    },
    {
      site: "LinkedIn",
      url: "",
      status: "checking" as const,
      category: "Professional",
    },
    {
      site: "Reddit",
      url: "https://reddit.com/user/testuser",
      status: "found" as const,
      category: "Social Media",
      responseTime: 567,
    },
    {
      site: "Steam",
      url: "",
      status: "error" as const,
      category: "Gaming",
    },
  ];

  return <ResultsTable results={mockResults} username="testuser" />;
}