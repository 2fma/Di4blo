import SearchForm from '../SearchForm';

export default function SearchFormExample() {
  const handleSearch = (username: string, options: any) => {
    console.log('Search triggered for:', username, 'with options:', options);
  };

  return <SearchForm onSearch={handleSearch} />;
}