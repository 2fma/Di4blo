import StatsDashboard from '../StatsDashboard';

export default function StatsDashboardExample() {
  // todo: remove mock functionality
  const mockResults = [
    { site: "GitHub", url: "https://github.com/testuser", status: "found" as const, responseTime: 245 },
    { site: "Twitter", url: "https://twitter.com/testuser", status: "found" as const, responseTime: 189 },
    { site: "Instagram", url: "", status: "not_found" as const },
    { site: "LinkedIn", url: "", status: "checking" as const },
    { site: "Reddit", url: "https://reddit.com/user/testuser", status: "found" as const, responseTime: 567 },
    { site: "Steam", url: "", status: "error" as const },
    { site: "Discord", url: "", status: "not_found" as const },
    { site: "YouTube", url: "", status: "not_found" as const },
  ];

  return <StatsDashboard results={mockResults} searchTime={23.5} isActive={true} />;
}