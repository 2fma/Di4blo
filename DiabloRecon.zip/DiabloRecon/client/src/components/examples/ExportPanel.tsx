import ExportPanel from '../ExportPanel';

export default function ExportPanelExample() {
  // todo: remove mock functionality
  const mockResults = [
    {
      site: "GitHub",
      url: "https://github.com/testuser",
      status: "found" as const,
      category: "Development",
    },
    {
      site: "Twitter",
      url: "https://twitter.com/testuser",
      status: "found" as const,
      category: "Social Media",
    },
    {
      site: "Instagram",
      url: "",
      status: "not_found" as const,
      category: "Social Media",
    },
  ];

  const handleExport = (format: 'txt' | 'pdf') => {
    console.log(`Export triggered for format: ${format}`);
  };

  return <ExportPanel results={mockResults} username="testuser" onExport={handleExport} />;
}