import { useState } from 'react';
import FilterSidebar from '../FilterSidebar';

export default function FilterSidebarExample() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>(['Social Media', 'Development']);

  // todo: remove mock functionality
  const mockCategories = {
    "Social Media": { total: 45, found: 8 },
    "Development": { total: 23, found: 4 },
    "Gaming": { total: 18, found: 2 },
    "Professional": { total: 12, found: 3 },
    "Forums": { total: 34, found: 1 },
    "Dating": { total: 8, found: 0 },
    "Shopping": { total: 15, found: 1 },
    "Music": { total: 9, found: 2 },
    "Video": { total: 7, found: 1 },
    "Photos": { total: 11, found: 3 },
  };

  const handleCategoryChange = (categories: string[]) => {
    setSelectedCategories(categories);
    console.log('Selected categories changed:', categories);
  };

  const handleClearFilters = () => {
    setSelectedCategories([]);
    console.log('Filters cleared');
  };

  return (
    <FilterSidebar
      categories={mockCategories}
      selectedCategories={selectedCategories}
      onCategoryChange={handleCategoryChange}
      onClearFilters={handleClearFilters}
    />
  );
}