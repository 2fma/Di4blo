import ProgressIndicator from '../ProgressIndicator';

export default function ProgressIndicatorExample() {
  const mockProgress = {
    current: 147,
    total: 300,
    foundCount: 12,
    currentSite: "GitHub",
  };

  return <ProgressIndicator progress={mockProgress} isActive={true} />;
}