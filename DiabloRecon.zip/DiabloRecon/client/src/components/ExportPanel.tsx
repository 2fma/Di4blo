import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, FileImage, CheckCircle, Clock } from "lucide-react";
import { SearchResult } from "@shared/schema";

interface ExportPanelProps {
  results: SearchResult[];
  username: string;
  onExport: (format: 'txt' | 'pdf') => void;
}

interface ExportStatus {
  format: 'txt' | 'pdf';
  status: 'idle' | 'generating' | 'ready' | 'downloaded';
  filename?: string;
}

export default function ExportPanel({ results, username, onExport }: ExportPanelProps) {
  const [exports, setExports] = useState<ExportStatus[]>([
    { format: 'txt', status: 'idle' },
    { format: 'pdf', status: 'idle' },
  ]);

  const foundResults = results.filter(r => r.status === "found");
  const canExport = foundResults.length > 0;

  const handleExport = async (format: 'txt' | 'pdf') => {
    console.log(`Starting ${format.toUpperCase()} export for ${foundResults.length} results`);
    
    setExports(prev => prev.map(exp => 
      exp.format === format 
        ? { ...exp, status: 'generating' }
        : exp
    ));

    // Simulate export generation
    setTimeout(() => {
      const filename = `${username}_results.${format}`;
      setExports(prev => prev.map(exp => 
        exp.format === format 
          ? { ...exp, status: 'ready', filename }
          : exp
      ));
      
      onExport(format);
    }, 2000);
  };

  const handleDownload = (format: 'txt' | 'pdf', filename: string) => {
    console.log(`Downloading ${filename}`);
    
    setExports(prev => prev.map(exp => 
      exp.format === format 
        ? { ...exp, status: 'downloaded' }
        : exp
    ));

    // Reset after a delay
    setTimeout(() => {
      setExports(prev => prev.map(exp => 
        exp.format === format 
          ? { ...exp, status: 'idle', filename: undefined }
          : exp
      ));
    }, 3000);
  };

  const getExportStatus = (format: 'txt' | 'pdf') => {
    return exports.find(exp => exp.format === format);
  };

  const renderExportButton = (format: 'txt' | 'pdf') => {
    const exportStatus = getExportStatus(format);
    const icon = format === 'txt' ? FileText : FileImage;
    const label = format === 'txt' ? 'Text Report' : 'PDF Report';

    if (!exportStatus) return null;

    switch (exportStatus.status) {
      case 'generating':
        return (
          <Button 
            disabled 
            variant="outline" 
            className="w-full"
            data-testid={`button-export-${format}`}
          >
            <Clock className="h-4 w-4 mr-2 animate-spin" />
            Generating {label}...
          </Button>
        );
      
      case 'ready':
        return (
          <Button 
            onClick={() => handleDownload(format, exportStatus.filename!)}
            variant="default" 
            className="w-full"
            data-testid={`button-download-${format}`}
          >
            <Download className="h-4 w-4 mr-2" />
            Download {label}
          </Button>
        );
      
      case 'downloaded':
        return (
          <Button 
            disabled 
            variant="outline" 
            className="w-full"
          >
            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
            Downloaded
          </Button>
        );
      
      default:
        return (
          <Button 
            onClick={() => handleExport(format)}
            disabled={!canExport}
            variant="outline" 
            className="w-full"
            data-testid={`button-export-${format}`}
          >
            {React.createElement(icon, { className: "h-4 w-4 mr-2" })}
            Export {label}
          </Button>
        );
    }
  };

  return (
    <Card className="w-full max-w-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Download className="h-4 w-4" />
          Export Results
        </CardTitle>
        <div className="text-sm text-muted-foreground">
          Export search results for "{username}"
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Found Profiles:</span>
            <Badge variant={foundResults.length > 0 ? "default" : "secondary"}>
              {foundResults.length}
            </Badge>
          </div>
          <div className="text-xs text-muted-foreground">
            {foundResults.length === 0 
              ? "No profiles found to export" 
              : `Ready to export ${foundResults.length} found profile${foundResults.length === 1 ? '' : 's'}`
            }
          </div>
        </div>

        <div className="space-y-2">
          {renderExportButton('txt')}
          {renderExportButton('pdf')}
        </div>

        {canExport && (
          <div className="text-xs text-muted-foreground p-2 bg-muted rounded-md">
            <strong>TXT:</strong> Plain text list of found profiles
            <br />
            <strong>PDF:</strong> Formatted report with search metadata
          </div>
        )}
      </CardContent>
    </Card>
  );
}